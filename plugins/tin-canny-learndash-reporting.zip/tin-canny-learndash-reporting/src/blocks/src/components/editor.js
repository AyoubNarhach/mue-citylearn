export const TinCannyPlaceholder = ({ children }) => {
	return (
		<div className="uo-tcr-placeholder-content">
			{ children }
		</div>
	);
}