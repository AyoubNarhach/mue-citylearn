<div id="reporting-user-navigation" class="reporting-breadcrumbs">
	<ul class="reporting-breadcrumbs-items">
		<li class="reporting-breadcrumbs-item reporting-breadcrumbs-item--guide">
			<span><?php _e( 'Tin Canny Reports', 'uncanny-learndash-reporting' ); ?></span>
		</li>
		<li id="user-navigate-link" class="reporting-breadcrumbs-item reporting-breadcrumbs-item--visible reporting-breadcrumbs-item--current">
				<span>
					<?php _e( 'xAPI Quiz Report', 'uncanny-learndash-reporting' ); ?>
				</span>
		</li>
	</ul>
</div>
