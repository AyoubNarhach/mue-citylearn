# Uncanny Owl In-plugin Notifications 

* Run this command in console to add notifications as a dependent
  * `git submodule add https://github.com/UncannyOwl/Uncanny-Owl-In-Plugin-Notifications.git src/notifications`
* Update using `git submodule update --remote`
* Include the notifications module by doing:
  * `require_once __DIR__ . '/your/path/to/notifications/notifications.php';
